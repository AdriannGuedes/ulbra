public class exercicio1 {
    public static void main(String[] args) {
            double n1=8.5;
            double n2=7.5;
            double n3=6.0;

            int peso1=3;
            int peso2=2;
            int peso3=5;

            //calculo parcial da nota:

            double parcial1=n1*peso1;
            double parcial2=n2*peso2;
            double parcial3=n3*peso3;

            //calculo média

            double media=(parcial1+parcial2+parcial3)/(peso1+peso2+peso3);
            System.out.println(media);




    }

}
