public class exercicio4 {

    public static void main(String[] args) {
        int x=5;



       while(x<1000){
           if (x%2==0){
               x=x+5;
           }else if(x%2==1){
               x=x*2;

           }
           System.out.println(x);
       }





    }



}
